g = 9.8;

m = linspace(0, 5, 100);
%m = 0.6;
P = m .* g
l = 0.179;
M = P .* l%moment
t = 0.008;%the thickness of the board
w = 0.08;
lb = 0.034;%length of bult
A = t.*w;

I = ((t.^3.*w)./12 + A.*((lb+t).*0.5).^2);

sigm = (M.*(t + 0.5.*lb))./I

sig0=3300e6;

X=sig0./sigm;
%plot(m,sigm);

plot(m,X,LineWidth=1);
legend("S.F. vs mass at front");
xlabel("mass at front [kg]");
ylabel("S.F.");
%%
g = 9.8;

%m = linspace(0, 5, 100);
m = 1;
P = m .* g;
l =  linspace(0, 0.179, 50);
M = P .* l;%moment
t = 0.008;%the thickness of the board
w = 0.08;
lb = 0.034;%length of bult
A = t.*w;

I = ((t.^3.*w)./12 + A.*((lb+t).*0.5).^2);

sigm = (M.*(t + 0.5.*lb))./I;

sig0=3300e6;

X=sig0./sigm;
%plot(m,sigm);

plot(l,X,LineWidth=1);
hold on;
y = ones(50) .* 10^4;
plot(l,y,LineWidth=1,Color='r');
legend("S.F. vs length of extension");
xlabel("length of extension [m]");
ylabel("S.F.");
%%
g = 9.8;

%m = linspace(0, 5, 100);
m = 1;
P = m .* g;
l =  linspace(0, 0.179, 50);
M = P .* l;%moment
t = linspace(0,0.010,50);%the thickness of the board
w = 0.08;
lb = 0.034;%length of bult
A = t.*w;

I = ((t.^3.*w)./12 + A.*((lb+t).*0.5).^2);

sigm = (M.*(t + 0.5.*lb))./I;

sig0=3300e6;

X=sig0./sigm;
%plot(m,sigm);

plot(t,X,LineWidth=1);
hold on;
%y = ones(50) .* 10^4;
%plot(l,y,LineWidth=1,Color='r');
legend("S.F. vs board thickness");
xlabel("thickness of acrylic board [m]");
ylabel("S.F.");